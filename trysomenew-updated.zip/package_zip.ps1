$dest = "trysomenew-updated.zip"
if (Test-Path $dest) { Remove-Item $dest }

$files = Get-ChildItem -Recurse | Where-Object { 
    $_.FullName -notmatch '\\(\.next|node_modules|\.git)\\' -and 
    $_.Name -ne "trysomenew-updated.zip" -and
    -not $_.PSIsContainer
}

Write-Host "Archiving $($files.Count) files..."
Compress-Archive -Path $files.FullName -DestinationPath $dest -CompressionLevel Optimal
Write-Host "[ZIP CREATED] Successfully generated $dest ($([math]::Round((Get-Item $dest).Length / 1MB, 2)) MB)"
